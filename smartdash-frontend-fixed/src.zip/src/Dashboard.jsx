import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import AddKpiForm from "./AddKpiForm";
import KpiChart from "./KpiChart";
import LineChart from "./LineChart";

function Dashboard({ username, role }) {
  const [kpis, setKpis] = useState([]);
  const [error, setError] = useState("");
  const [kpiToEdit, setKpiToEdit] = useState(null);
  const [selectedDepartment, setSelectedDepartment] = useState("Hepsi");
  const navigate = useNavigate();

  const fetchKpis = async () => {
    try {
      const token = localStorage.getItem("token");
      const res = await axios.get("http://localhost:5000/api/kpis", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setKpis(res.data);
    } catch (err) {
      console.error("KPI verileri alınamadı:", err);
      setError("KPI verileri alınamadı.");
    }
  };

  useEffect(() => {
    fetchKpis();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm("Bu KPI silinsin mi?")) return;
    try {
      const token = localStorage.getItem("token");
      await axios.delete(`http://localhost:5000/api/kpis/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchKpis();
    } catch (err) {
      console.error("Silme hatası:", err);
      alert("KPI silinemedi.");
    }
  };

  const handleEdit = (kpi) => setKpiToEdit(kpi);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  const filteredKpis =
    selectedDepartment === "Hepsi"
      ? kpis
      : kpis.filter((kpi) => kpi.department === selectedDepartment);

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 md:px-10 text-gray-800">
      <div className="max-w-6xl mx-auto">
        {/* ÜST BAR */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <h1 className="text-3xl font-bold text-blue-700">
            Hoş Geldin, {username}! 🚀
          </h1>
          <button
            onClick={handleLogout}
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded"
          >
            Çıkış Yap
          </button>
        </div>

        {/* FORM */}
        {role === "admin" && (
          <div className="bg-white shadow-md p-6 rounded mb-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">
              {kpiToEdit ? "KPI Güncelle" : "Yeni KPI Ekle"}
            </h2>
            <AddKpiForm
              onSuccess={fetchKpis}
              kpiToEdit={kpiToEdit}
              clearEdit={() => setKpiToEdit(null)}
            />
          </div>
        )}

        {/* FİLTRE */}
        <div className="mb-6">
          <label className="block font-medium mb-2 text-gray-700">
            Departman Filtrele:
          </label>
          <select
            value={selectedDepartment}
            onChange={(e) => setSelectedDepartment(e.target.value)}
            className="border border-gray-300 p-2 rounded w-full sm:w-64"
          >
            <option value="Hepsi">Hepsi</option>
            {[...new Set(kpis.map((kpi) => kpi.department))].map((dept) => (
              <option key={dept} value={dept}>
                {dept}
              </option>
            ))}
          </select>
        </div>

        {/* GRAFİKLER */}
        {filteredKpis.length > 0 && <KpiChart kpis={filteredKpis} />}
        {filteredKpis.length > 0 && <LineChart kpis={filteredKpis} />}

        {/* TABLO */}
        {error && <p className="text-red-500 text-center">{error}</p>}

        {filteredKpis.length === 0 ? (
          <p className="text-center text-gray-500">
            Bu departmana ait KPI verisi yok.
          </p>
        ) : (
          <div className="overflow-x-auto bg-white shadow-md rounded text-sm sm:text-base">
            <table className="min-w-full">
              <thead className="bg-blue-600 text-white">
                <tr>
                  <th className="px-4 py-3 text-left">Ad</th>
                  <th className="px-4 py-3 text-left">Departman</th>
                  <th className="px-4 py-3 text-left">Hedef</th>
                  <th className="px-4 py-3 text-left">Gerçekleşen</th>
                  <th className="px-4 py-3 text-left">Başarı</th>
                  <th className="px-4 py-3 text-left">Birim</th>
                  <th className="px-4 py-3 text-left">Sıklık</th>
                  {role === "admin" && (
                    <th className="px-4 py-3 text-center">İşlem</th>
                  )}
                </tr>
              </thead>
              <tbody>
                {filteredKpis.map((kpi) => {
                  const target = Number(kpi.target);
                  const actual = Number(kpi.actual);
                  const successRate =
                    target > 0 && !isNaN(actual)
                      ? Math.round((actual / target) * 100)
                      : 0;
                  const color =
                    successRate >= 90
                      ? "bg-green-500"
                      : successRate >= 60
                      ? "bg-yellow-400"
                      : "bg-red-500";

                  return (
                    <tr
                      key={kpi._id}
                      className="border-b hover:bg-gray-100 transition"
                    >
                      <td className="px-4 py-3">{kpi.name}</td>
                      <td className="px-4 py-3">{kpi.department}</td>
                      <td className="px-4 py-3">{kpi.target}</td>
                      <td className="px-4 py-3">{kpi.actual || 0}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`text-xs font-semibold px-2 py-1 rounded text-white ${color}`}
                        >
                          %{successRate}
                        </span>
                      </td>
                      <td className="px-4 py-3">{kpi.unit}</td>
                      <td className="px-4 py-3">{kpi.frequency}</td>
                      {role === "admin" && (
                        <td className="px-4 py-3 flex flex-wrap gap-2 justify-center">
                          <button
                            onClick={() => handleEdit(kpi)}
                            className="bg-yellow-400 hover:bg-yellow-500 text-white px-3 py-1 rounded"
                          >
                            Düzenle
                          </button>
                          <button
                            onClick={() => handleDelete(kpi._id)}
                            className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded"
                          >
                            Sil
                          </button>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default Dashboard;
