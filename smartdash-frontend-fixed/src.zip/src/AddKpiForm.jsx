import { useState, useEffect } from "react";
import axios from "axios";

function AddKpiForm({ onSuccess, kpiToEdit, clearEdit }) {
  const [form, setForm] = useState({
    name: "",
    department: "",
    unit: "",
    target: "",
    actual: "", // ✅ actual eklendi
    frequency: "monthly",
  });

  // Eğer bir KPI düzenlenmek üzere seçildiyse formu doldur
  useEffect(() => {
    if (kpiToEdit) {
      setForm({
        name: kpiToEdit.name,
        department: kpiToEdit.department,
        unit: kpiToEdit.unit,
        target: kpiToEdit.target,
        actual: kpiToEdit.actual || "", // ✅ actual ekleniyor
        frequency: kpiToEdit.frequency,
      });
    }
  }, [kpiToEdit]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");

    // Sayısal değerleri düzgün parse et
    const payload = {
      ...form,
      target: Number(form.target),
      actual: Number(form.actual),
    };

    try {
      if (kpiToEdit) {
        // Güncelleme
        await axios.put(
          `http://localhost:5000/api/kpis/${kpiToEdit._id}`,
          payload,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
      } else {
        // Ekleme
        await axios.post("http://localhost:5000/api/kpis", payload, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
      }

      onSuccess();
      setForm({
        name: "",
        department: "",
        unit: "",
        target: "",
        actual: "",
        frequency: "monthly",
      });
      clearEdit && clearEdit();
    } catch (err) {
      console.error("Form gönderilemedi:", err);
      alert("Bir hata oluştu.");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2 flex-wrap">
      <input
        type="text"
        name="name"
        placeholder="KPI Adı"
        value={form.name}
        onChange={handleChange}
        className="border p-2 rounded"
      />
      <input
        type="text"
        name="department"
        placeholder="Departman"
        value={form.department}
        onChange={handleChange}
        className="border p-2 rounded"
      />
      <input
        type="text"
        name="unit"
        placeholder="Birim"
        value={form.unit}
        onChange={handleChange}
        className="border p-2 rounded"
      />
      <input
        type="number"
        name="target"
        placeholder="Hedef"
        value={form.target}
        onChange={handleChange}
        className="border p-2 rounded"
      />
      <input
        type="number"
        name="actual"
        placeholder="Gerçekleşen"
        value={form.actual}
        onChange={handleChange}
        className="border p-2 rounded"
      />
      <select
        name="frequency"
        value={form.frequency}
        onChange={handleChange}
        className="border p-2 rounded"
      >
        <option value="daily">Günlük</option>
        <option value="weekly">Haftalık</option>
        <option value="monthly">Aylık</option>
      </select>

      <button
        type="submit"
        className={`px-4 py-2 text-white rounded ${
          kpiToEdit ? "bg-yellow-600 hover:bg-yellow-700" : "bg-blue-600 hover:bg-blue-700"
        }`}
      >
        {kpiToEdit ? "Güncelle" : "Ekle"}
      </button>

      {kpiToEdit && (
        <button
          type="button"
          onClick={clearEdit}
          className="px-4 py-2 bg-gray-400 hover:bg-gray-500 text-white rounded"
        >
          Vazgeç
        </button>
      )}
    </form>
  );
}

export default AddKpiForm;
